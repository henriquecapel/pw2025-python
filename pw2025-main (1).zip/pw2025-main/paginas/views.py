from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import Cliente, Fotografo, Estudio, SessaoFoto
from django.contrib.messages.views import SuccessMessageMixin
from django.views.generic.edit import CreateView
from django.contrib.auth.models import User, Group
from .forms import UsuarioCadastroForm
from django.shortcuts import get_list_or_404

# Crie a view no final do arquivo ou em outro local que faça sentido
class CadastroClienteView(CreateView):
    model = User
    # Não tem o fields, pois ele é definido no forms.py
    form_class = UsuarioCadastroForm
    # Pode utilizar o seu form padrão
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('login')
    extra_context = {'titulo': 'Cadastrar cliente'}


    def form_valid(self, form):
        # Faz o comportamento padrão do form_valid
        url = super().form_valid(form)
        # Busca ou cria um grupo com esse nome
        grupo, criado = Group.objects.get_or_create(name='Cliente')
        # Acessa o objeto criado e adiciona o usuário no grupo acima
        self.object.groups.add(grupo)
        # Cria um cliente para o User
        cliente = Cliente.objects.create(user=self.object)
        # Retorna a URL de sucesso
        return url


class CadastroFotografoView(CreateView):
    model = User
    # Não tem o fields, pois ele é definido no forms.py
    form_class = UsuarioCadastroForm
    # Pode utilizar o seu form padrão
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('login')
    extra_context = {'titulo': 'Cadastrar Fotógrafo'}


    def form_valid(self, form):
        # Faz o comportamento padrão do form_valid
        url = super().form_valid(form)
        # Busca ou cria um grupo com esse nome
        grupo, criado = Group.objects.get_or_create(name='Fotógrafo')
        # Acessa o objeto criado e adiciona o usuário no grupo acima
        self.object.groups.add(grupo)
        # Cria um cliente para o User
        cliente = Fotografo.objects.create(user=self.object)
        # Retorna a URL de sucesso
        return url



class Inicio(TemplateView):
    template_name = "paginas/index.html"


class ClienteCreate(CreateView):
    model = Cliente
    fields = ['nome', 'telefone']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}

class FotografoCreate(CreateView):
    model = Fotografo
    fields = ['nome', 'especialidade', 'telefone']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}

class EstudioCreate(CreateView):
    model = Estudio
    fields = ['nome', 'endereco', 'telefone']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}

class SessaoFotoCreate(CreateView):
    model = SessaoFoto
    fields = ['data', 'horario', 'tipo', 'duracao', 'cliente', 'fotografo', 'estudio', 'finalizado', 'valor']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}


#############################################################


class ClienteUpdate(UpdateView):
    model = Cliente
    fields = ['nome', 'telefone']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}


class FotografoUpdate(UpdateView):
    model = Fotografo
    fields = ['nome', 'especialidade', 'telefone']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}

class EstudioUpdate(UpdateView):
    model = Estudio
    fields = ['nome', 'endereco', 'telefone']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}

class SessaoFotoUpdate(UpdateView):
    model = SessaoFoto
    fields = ['data', 'horario', 'tipo', 'duracao', 'cliente', 'fotografo', 'estudio', 'finalizado', 'valor']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}

    def get_object(self, queryset = None):
        #Busca o objeto ou retorna 404
        obj = get_object_or_404(MinhasSolicitacoes, pk=self.kwargs['pk'], solicitado_por=self.request.User)
        return object

#########################################################

class ClienteDelete(DeleteView):
    model = Cliente
    fields = ['nome', 'telefone', 'email']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}


class FotografoDelete(DeleteView):
    model = Fotografo
    fields = ['nome', 'especialidade', 'telefone']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}

class EstudioDelete(DeleteView):
    model = Estudio
    fields = ['nome', 'endereco', 'telefone']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}

class SessaoFotoDelete(DeleteView):
    model = SessaoFoto
    fields = ['data', 'horario', 'tipo', 'duracao', 'cliente', 'fotografo', 'estudio', 'finalizado', 'valor']
    template_name = 'paginas/form.html'
    success_url = reverse_lazy('inicio')
    extra_content = {'Cadastro Fotografia': 'Atualização de fotos', 'Enviar dados': 'protocolar',}

    def get_object(self, queryset = None):
        #Busca o objeto ou retorna 404
        from django.shortcuts import get_list_or_404(MinhasSolicitacoes, pk=self.kwargs['pk'], solicitado_por=self.request.User)
        return object

#######################

#Fazer uma herança para ter tudo quetem na SolicitacaoList
class MinhasSolicitacoes(SolicitacaoList):
 def get_queryset(self):
        qs = Solicitacao.objects.filter(solicitado_por=self.request.user)
        return qs
    

class PerfilCliente(LoginRequiredMixin, ListView):
    Model = Cliente
    fields = ['nome', 'LoginRequiredMixin, ListViewail']
    template_name = 'paginas/form.html'
   
class PerfilFotografo(LoginRequiredMixin, ListView):
    model = Fotografo
    fields = ['nome', 'especialidade', 'telefone']
    template_name = 'paginas/form.html'
  
class PerfilEstudioD(LoginRequiredMixin, ListView):
    model = Estudio
    fields = ['nome', 'endereco', 'telefone']
    template_name = 'paginas/form.html'
   

class PerfilSessaoFoto(LoginRequiredMixin, ListView):
    model = SessaoFoto
    fields = ['data', 'horario', 'tipo', 'duracao', 'cliente', 'fotografo', 'estudio', 'finalizado', 'valor']
    template_name = 'paginas/form.html'
 
  ##############################################################

class CriarClienteView(SuccessMessageMixin, CreateView):
    model = Cliente
    fields = ['nome', 'matricula', 'cpf', 'email', 'telefone']
    success_url = '/alunos/'
    success_message = "cliente criado com sucesso!"

class PerfilFotografo(SuccessMessageMixin, CreateView):
    model = Fotografo
    fields = ['nome', 'especialidade', 'telefone']
    success_url = '/alunos/'
    success_message = "Perfil fotografo criado com sucesso!"
class PerfilEstudioD(SuccessMessageMixin, CreateView):
    model = Estudio
    fields = ['nome', 'endereco', 'telefone']
    success_url = '/alunos/'
    success_message = "Estudio criado com sucesso!"

class PerfilSessaoFoto(SuccessMessageMixin, CreateView):
    model = SessaoFoto
    fields = ['data', 'horario', 'tipo', 'duracao', 'cliente', 'fotografo', 'estudio', 'finalizado', 'valor']
    success_url = '/alunos/'
    success_message = "Sessão criado com sucesso!"